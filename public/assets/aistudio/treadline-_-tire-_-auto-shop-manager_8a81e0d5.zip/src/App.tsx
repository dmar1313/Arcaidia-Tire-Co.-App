import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  onAuthStateChanged,
  signInWithPopup,
  signOut,
  type User,
} from 'firebase/auth';
import {
  collection,
  doc,
  limit,
  onSnapshot,
  orderBy,
  query,
} from 'firebase/firestore';
import {
  Bell,
  Building2,
  ClipboardList,
  Eye,
  LayoutDashboard,
  LogOut,
  Plus,
  Tag,
  Users,
} from 'lucide-react';
import { AuthGate } from './components/AuthGate';
import { BrandLogo, DEFAULT_SHOP_NAME } from './components/BrandLogo';
import { CompanyStaffExportsView } from './components/CompanyStaffExportsView';
import { CustomersVehiclesView } from './components/CustomersVehiclesView';
import { DashboardBoard } from './components/DashboardBoard';
import { OfflineIndicator } from './components/OfflineIndicator';
import { PriceListView } from './components/PriceListView';
import { PWAInstallButton } from './components/PWAInstallButton';
import { WorkOrderModal } from './components/WorkOrderModal';
import {
  auth,
  db,
  emailToStaffId,
  googleProvider,
  handleFirestoreError,
  OperationType,
  testFirestoreConnection,
} from './lib/firebase';
import {
  dispatchStaffPushNotification,
  getStaffNotificationPermission,
  playBayChime,
  requestStaffNotificationPermission,
} from './lib/notifications';
import {
  claimAndCreateShop,
  markNotificationRead,
  quickUpdateWorkOrderStatus,
  saveCompanyProfile,
  seedDefaultCatalog,
  type ActorInfo,
} from './lib/shopService';
import {
  BOOTSTRAP_ADMIN_EMAIL,
  type CompanyProfile,
  type Customer,
  type PriceAuditEntry,
  type ServiceCatalogItem,
  type StaffMember,
  type StaffNotification,
  type StaffRole,
  type Vehicle,
  type WorkOrder,
  type WorkOrderStatus,
} from './types';

type NavTab = 'board' | 'orders' | 'customers' | 'prices' | 'company';

export default function App() {
  const [authUser, setAuthUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  const [myStaffDoc, setMyStaffDoc] = useState<StaffMember | null | undefined>(undefined);
  const [shopInitialized, setShopInitialized] = useState<boolean | undefined>(undefined);
  const [claimingShop, setClaimingShop] = useState(false);
  const [company, setCompany] = useState<CompanyProfile | null>(null);
  const [staff, setStaff] = useState<StaffMember[]>([]);
  const [services, setServices] = useState<ServiceCatalogItem[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [workOrders, setWorkOrders] = useState<WorkOrder[]>([]);
  const [priceAuditLog, setPriceAuditLog] = useState<PriceAuditEntry[]>([]);
  const [notifications, setNotifications] = useState<StaffNotification[]>([]);

  const [activeTab, setActiveTab] = useState<NavTab>('board');
  const [viewAsMechanic, setViewAsMechanic] = useState(false);
  const [showAlertsDrawer, setShowAlertsDrawer] = useState(false);
  const [chimeEnabled, setChimeEnabled] = useState(true);

  const [modalOrderId, setModalOrderId] = useState<string | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [prefillCustomer, setPrefillCustomer] = useState<Customer | null>(null);
  const [prefillVehicle, setPrefillVehicle] = useState<Vehicle | null>(null);

  // Quick onboarding state for first-time setup
  const [quickShopName, setQuickShopName] = useState(DEFAULT_SHOP_NAME);
  const [quickShopPhone, setQuickShopPhone] = useState('');
  const [quickTaxRate, setQuickTaxRate] = useState('7.0');
  const [seedMenuChecked, setSeedMenuChecked] = useState(true);
  const [onboardingSaving, setOnboardingSaving] = useState(false);
  const [onboardError, setOnboardError] = useState<string | null>(null);

  const seenNotifIdsRef = useRef<Set<string>>(new Set());
  const notifBootstrappedRef = useRef(false);

  useEffect(() => {
    testFirestoreConnection();
    const unsub = onAuthStateChanged(auth, (user) => {
      setAuthUser(user);
      setAuthReady(true);
      if (!user) {
        setMyStaffDoc(undefined);
      }
    });
    return unsub;
  }, []);

  const isBootstrapAdmin =
    !!authUser?.email &&
    authUser.emailVerified &&
    authUser.email.toLowerCase() === BOOTSTRAP_ADMIN_EMAIL;

  // Step 1: Resolve current user's staff record & shop initialization status
  useEffect(() => {
    if (!authReady || !authUser || !authUser.email || !authUser.emailVerified) {
      setMyStaffDoc(undefined);
      setShopInitialized(undefined);
      return;
    }
    const staffId = emailToStaffId(authUser.email);
    const path = `staff/${staffId}`;
    const unsubStaff = onSnapshot(
      doc(db, 'staff', staffId),
      (snap) => {
        setMyStaffDoc(snap.exists() ? (snap.data() as StaffMember) : null);
      },
      (err) => {
        if (!isBootstrapAdmin) {
          setMyStaffDoc(null);
        } else {
          handleFirestoreError(err, OperationType.GET, path);
        }
      }
    );

    const unsubStatus = onSnapshot(
      doc(db, 'shop_status', 'default'),
      (snap) => {
        setShopInitialized(snap.exists());
      },
      () => {
        setShopInitialized(false);
      }
    );

    return () => {
      unsubStaff();
      unsubStatus();
    };
  }, [authReady, authUser, isBootstrapAdmin]);

  const isAuthorizedStaff = useMemo(() => {
    if (!authUser || !authUser.emailVerified) return false;
    if (isBootstrapAdmin) return true;
    return !!myStaffDoc && myStaffDoc.active === true;
  }, [authUser, isBootstrapAdmin, myStaffDoc]);

  const actualRole: StaffRole = useMemo(() => {
    if (isBootstrapAdmin) return 'management';
    if (myStaffDoc?.active && myStaffDoc.role === 'management') return 'management';
    return 'mechanic';
  }, [isBootstrapAdmin, myStaffDoc]);

  const effectiveRole: StaffRole =
    actualRole === 'management' && viewAsMechanic ? 'mechanic' : actualRole;

  const actor: ActorInfo | null = useMemo(() => {
    if (!authUser) return null;
    return {
      uid: authUser.uid,
      name: myStaffDoc?.name || authUser.displayName || authUser.email || 'Staff',
      email: authUser.email || '',
      role: actualRole,
    };
  }, [authUser, myStaffDoc, actualRole]);

  // Step 2: Attach Firestore real-time listeners once authorized and not mid-claim
  useEffect(() => {
    if (!isAuthorizedStaff || claimingShop) return;

    const unsubs: Array<() => void> = [];

    unsubs.push(
      onSnapshot(
        doc(db, 'company', 'default'),
        (snap) => {
          setCompany(snap.exists() ? (snap.data() as CompanyProfile) : null);
        },
        (err) => handleFirestoreError(err, OperationType.GET, 'company/default')
      )
    );

    unsubs.push(
      onSnapshot(
        query(collection(db, 'staff'), orderBy('name', 'asc')),
        (snap) => setStaff(snap.docs.map((d) => d.data() as StaffMember)),
        (err) => handleFirestoreError(err, OperationType.LIST, 'staff')
      )
    );

    unsubs.push(
      onSnapshot(
        query(collection(db, 'services'), orderBy('name', 'asc')),
        (snap) => setServices(snap.docs.map((d) => d.data() as ServiceCatalogItem)),
        (err) => handleFirestoreError(err, OperationType.LIST, 'services')
      )
    );

    unsubs.push(
      onSnapshot(
        query(collection(db, 'customers'), orderBy('name', 'asc')),
        (snap) => setCustomers(snap.docs.map((d) => d.data() as Customer)),
        (err) => handleFirestoreError(err, OperationType.LIST, 'customers')
      )
    );

    unsubs.push(
      onSnapshot(
        query(collection(db, 'vehicles'), orderBy('createdAt', 'desc')),
        (snap) => setVehicles(snap.docs.map((d) => d.data() as Vehicle)),
        (err) => handleFirestoreError(err, OperationType.LIST, 'vehicles')
      )
    );

    unsubs.push(
      onSnapshot(
        query(collection(db, 'work_orders'), orderBy('createdAt', 'desc')),
        { includeMetadataChanges: true },
        (snap) => {
          setWorkOrders(
            snap.docs.map((d) => ({
              ...(d.data() as WorkOrder),
              hasPendingWrites: d.metadata.hasPendingWrites,
            }))
          );
        },
        (err) => handleFirestoreError(err, OperationType.LIST, 'work_orders')
      )
    );

    unsubs.push(
      onSnapshot(
        query(collection(db, 'price_audit_log'), orderBy('createdAt', 'desc'), limit(50)),
        (snap) => setPriceAuditLog(snap.docs.map((d) => d.data() as PriceAuditEntry)),
        (err) => handleFirestoreError(err, OperationType.LIST, 'price_audit_log')
      )
    );

    unsubs.push(
      onSnapshot(
        query(collection(db, 'staff_notifications'), orderBy('createdAt', 'desc'), limit(30)),
        (snap) => {
          const list = snap.docs.map((d) => d.data() as StaffNotification);
          setNotifications(list);

          if (!notifBootstrappedRef.current) {
            list.forEach((n) => seenNotifIdsRef.current.add(n.id));
            notifBootstrappedRef.current = true;
            return;
          }

          for (const n of list) {
            if (!seenNotifIdsRef.current.has(n.id)) {
              seenNotifIdsRef.current.add(n.id);
              const isFromSelf = n.createdByUid === authUser?.uid;
              const matchesRole =
                n.targetRole === 'all' || n.targetRole === effectiveRole;
              if (!isFromSelf && matchesRole) {
                dispatchStaffPushNotification(n.title, n.body, n.id);
                if (chimeEnabled) playBayChime();
              }
            }
          }
        },
        (err) => handleFirestoreError(err, OperationType.LIST, 'staff_notifications')
      )
    );

    return () => {
      unsubs.forEach((u) => u());
    };
  }, [isAuthorizedStaff, claimingShop, authUser?.uid, effectiveRole, chimeEnabled]);

  const modalOrder = useMemo(
    () => (modalOrderId ? workOrders.find((w) => w.id === modalOrderId) || null : null),
    [workOrders, modalOrderId]
  );

  const pendingWritesCount = useMemo(
    () => workOrders.filter((w) => w.hasPendingWrites).length,
    [workOrders]
  );

  const relevantNotifications = useMemo(() => {
    if (!authUser) return [];
    return notifications.filter(
      (n) => n.targetRole === 'all' || n.targetRole === effectiveRole
    );
  }, [notifications, authUser, effectiveRole]);

  const unreadCount = useMemo(() => {
    if (!authUser) return 0;
    return relevantNotifications.filter((n) => !n.readByUids?.includes(authUser.uid)).length;
  }, [relevantNotifications, authUser]);

  const handleSignIn = async () => {
    setAuthError(null);
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err) {
      setAuthError(err instanceof Error ? err.message : 'Sign-in failed.');
    }
  };

  const handleSignOut = async () => {
    await signOut(auth);
    setViewAsMechanic(false);
  };

  const handleQuickStatus = async (wo: WorkOrder, nextStatus: WorkOrderStatus) => {
    if (!actor) return;
    await quickUpdateWorkOrderStatus(wo, nextStatus, { ...actor, role: effectiveRole });
  };

  const handleQuickOnboard = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!actor || !quickShopName.trim()) return;
    setOnboardingSaving(true);
    setOnboardError(null);
    try {
      await saveCompanyProfile(
        {
          shopName: quickShopName,
          address: '',
          cityStateZip: '',
          phone: quickShopPhone,
          email: actor.email,
          iowaTaxRate: Number(quickTaxRate) || 7.0,
          workOrderPrefix: 'WO-',
          nextOrderNumber: 1001,
          receiptFooter: 'Thank you for your business. Torque lug nuts after 50 miles.',
        },
        actor.uid,
        !company,
        { name: actor.name, email: actor.email }
      );
      if (seedMenuChecked && services.length === 0) {
        await seedDefaultCatalog(actor.uid);
      }
    } catch (err) {
      setOnboardError(err instanceof Error ? err.message : 'Unable to save shop profile.');
    } finally {
      setOnboardingSaving(false);
    }
  };

  if (!authReady) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <p className="text-sm text-slate-500">Loading shop workspace…</p>
      </div>
    );
  }

  if (!authUser) {
    return <AuthGate mode="login" authError={authError} onSignIn={handleSignIn} />;
  }

  if (!isBootstrapAdmin && (myStaffDoc === undefined || shopInitialized === undefined)) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <p className="text-sm text-slate-500">Verifying staff access…</p>
      </div>
    );
  }

  if (!isAuthorizedStaff || !actor || claimingShop) {
    return (
      <AuthGate
        mode={shopInitialized ? 'unauthorized' : 'create_shop'}
        userEmail={authUser.email}
        userDisplayName={authUser.displayName}
        onSignIn={handleSignIn}
        onSignOut={handleSignOut}
        onCreateShop={async (payload) => {
          if (!authUser.email) return;
          setClaimingShop(true);
          try {
            await claimAndCreateShop({
              ownerName: payload.ownerName,
              ownerEmail: authUser.email,
              ownerUid: authUser.uid,
              shopName: payload.shopName,
              phone: payload.phone,
              iowaTaxRate: payload.iowaTaxRate,
              seedStarterServices: payload.seedStarterServices,
            });
          } finally {
            setClaimingShop(false);
          }
        }}
      />
    );
  }

  const isMechanicView = effectiveRole === 'mechanic';

  const navItems: Array<{ id: NavTab; label: string; shortLabel: string; icon: React.ReactNode }> = [
    {
      id: 'board',
      label: isMechanicView ? 'Bay Board' : "Today's Board",
      shortLabel: isMechanicView ? 'Bay' : 'Board',
      icon: <LayoutDashboard className="h-4 w-4" />,
    },
    {
      id: 'orders',
      label: 'All Work Orders',
      shortLabel: 'Orders',
      icon: <ClipboardList className="h-4 w-4" />,
    },
    {
      id: 'customers',
      label: 'Customers & Vehicles',
      shortLabel: 'Vehicles',
      icon: <Users className="h-4 w-4" />,
    },
    {
      id: 'prices',
      label: isMechanicView ? 'Price List (Locked)' : 'Price List',
      shortLabel: 'Prices',
      icon: <Tag className="h-4 w-4" />,
    },
    ...(!isMechanicView
      ? [
          {
            id: 'company' as NavTab,
            label: 'Team, Shop & Exports',
            shortLabel: 'Team',
            icon: <Building2 className="h-4 w-4" />,
          },
        ]
      : []),
  ];

  const effectiveTab: NavTab =
    isMechanicView && activeTab === 'company' ? 'board' : activeTab;

  const activeTitle =
    navItems.find((n) => n.id === effectiveTab)?.label ||
    (isMechanicView ? 'Bay Board' : "Today's Board");

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col md:flex-row">
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex md:w-60 md:flex-col md:fixed md:inset-y-0 bg-white border-r border-slate-200 border-t-2 border-t-[#C81E2B] z-30">
        <div className="px-4 py-3 flex flex-col items-start justify-center border-b border-slate-200 bg-white">
          <BrandLogo size="md" />
          {company?.shopName &&
            company.shopName.trim().toLowerCase() !== DEFAULT_SHOP_NAME.toLowerCase() && (
              <span className="mt-1 text-xs font-semibold text-slate-700 truncate max-w-full">
                {company.shopName}
              </span>
            )}
        </div>

        <nav className="flex-1 p-3 space-y-1">
          {navItems.map((item) => {
            const active = effectiveTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${
                  active
                    ? 'bg-slate-900 text-white'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <span className={active ? 'text-[#E11D48]' : ''}>{item.icon}</span>
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-3 border-t border-slate-200 space-y-2.5">
          {actualRole === 'management' && (
            <button
              type="button"
              onClick={() => setViewAsMechanic((v) => !v)}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium border transition-colors ${
                viewAsMechanic
                  ? 'bg-red-50 border-red-200 text-red-800'
                  : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
              }`}
            >
              <span className="inline-flex items-center gap-1.5">
                <Eye className="h-3.5 w-3.5" />
                {viewAsMechanic ? 'Mechanic View Active' : 'Preview Mechanic View'}
              </span>
            </button>
          )}

          <div className="px-2 py-1 flex items-center justify-between gap-2">
            <div className="min-w-0">
              <p className="text-xs font-semibold text-slate-900 truncate">{actor.name}</p>
              <p className="text-[11px] text-slate-500 capitalize">{effectiveRole}</p>
            </div>
            <button
              type="button"
              onClick={handleSignOut}
              className="p-2 rounded-lg text-slate-400 hover:text-slate-800 hover:bg-slate-100"
              aria-label="Sign out"
              title="Sign out"
            >
              <LogOut className="h-4 w-4" />
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content Shell */}
      <div
        className={`flex-1 md:pl-60 flex flex-col min-h-screen pb-20 md:pb-8 ${
          showCreateModal || modalOrder ? 'print:hidden' : ''
        }`}
      >
        {/* Top Bar */}
        <header className="sticky top-0 z-20 h-14 md:h-16 bg-white/95 backdrop-blur-sm border-b border-slate-200 px-4 md:px-6 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <div className="md:hidden shrink-0">
              <BrandLogo size="sm" />
            </div>
            <h1 className="text-base md:text-lg font-bold tracking-tight text-slate-900 truncate">
              {activeTitle}
            </h1>
            {viewAsMechanic && (
              <span className="hidden sm:inline text-xs font-medium text-[#C81E2B]">
                · Bay Preview
              </span>
            )}
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <PWAInstallButton />

            {/* Staff Alerts Bell */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setShowAlertsDrawer((s) => !s)}
                className="relative p-2 rounded-lg border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 min-h-[40px] min-w-[40px] flex items-center justify-center"
                aria-label="Staff Notifications"
              >
                <Bell className="h-4 w-4" />
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 h-4 min-w-[16px] px-1 rounded-full bg-[#C81E2B] text-[10px] font-bold text-white flex items-center justify-center font-mono">
                    {unreadCount}
                  </span>
                )}
              </button>

              {showAlertsDrawer && (
                <div className="absolute right-0 mt-2 w-80 bg-white border border-slate-200 rounded-xl shadow-xl z-40 overflow-hidden">
                  <div className="px-4 py-2.5 border-b border-slate-200 flex items-center justify-between gap-2">
                    <span className="text-xs font-semibold text-slate-900">
                      Staff Bay Alerts ({effectiveRole})
                    </span>
                    <div className="flex items-center gap-2">
                      {getStaffNotificationPermission() === 'default' && (
                        <button
                          type="button"
                          onClick={() => requestStaffNotificationPermission()}
                          className="text-[11px] font-medium text-[#C81E2B] hover:text-[#A61722]"
                        >
                          Enable Push
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => setShowAlertsDrawer(false)}
                        className="text-xs text-slate-500 hover:text-slate-900"
                      >
                        Close
                      </button>
                    </div>
                  </div>
                  <div className="max-h-80 overflow-y-auto divide-y divide-slate-100">
                    {relevantNotifications.length === 0 ? (
                      <p className="p-4 text-xs text-slate-500">
                        No staff alerts yet. Mechanics are pinged on new jobs; management is pinged
                        when jobs are marked Ready.
                      </p>
                    ) : (
                      relevantNotifications.map((n) => {
                        const isUnread = !n.readByUids?.includes(authUser.uid);
                        return (
                          <button
                            key={n.id}
                            type="button"
                            onClick={() => {
                              markNotificationRead(n.id, authUser.uid, n.readByUids || []);
                              const matched = workOrders.find((w) => w.id === n.workOrderId);
                              if (matched) {
                                setModalOrderId(matched.id);
                                setShowAlertsDrawer(false);
                              }
                            }}
                            className={`w-full text-left px-4 py-3 hover:bg-slate-50 transition-colors ${
                              isUnread ? 'bg-red-50/40' : ''
                            }`}
                          >
                            <p className="text-xs font-semibold text-slate-900">{n.title}</p>
                            <p className="text-xs text-slate-600 mt-0.5">{n.body}</p>
                          </button>
                        );
                      })
                    )}
                  </div>
                </div>
              )}
            </div>

            <button
              type="button"
              onClick={() => {
                setPrefillCustomer(null);
                setPrefillVehicle(null);
                setShowCreateModal(true);
              }}
              className="inline-flex items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-2 text-xs font-semibold text-white hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0 min-h-[40px]"
            >
              <Plus className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">New Work Order</span>
              <span className="sm:hidden">New Job</span>
            </button>
          </div>
        </header>

        {/* Main Viewport */}
        <main className="flex-1 max-w-6xl w-full mx-auto px-4 md:px-6 py-6 space-y-6">
          {/* First-time Shop Setup Card (only shown when company/default does not exist yet) */}
          {!company && actualRole === 'management' && activeTab === 'board' && (
            <section className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  Set up your shop profile &amp; starter service menu
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Configure your shop name for PDF receipts, Iowa sales tax rate, and load common
                  tire, oil change, and tune-up prices.
                </p>
                {onboardError && (
                  <p className="mt-2 text-xs text-red-700 bg-red-50 border border-red-200 rounded-lg px-3 py-2">
                    {onboardError}
                  </p>
                )}
              </div>
              <form onSubmit={handleQuickOnboard} className="grid grid-cols-1 sm:grid-cols-4 gap-3 items-end">
                  <label className="block text-xs font-medium text-slate-600 sm:col-span-2">
                    Shop Name *
                    <input
                      type="text"
                      required
                      placeholder="e.g., Arcadia Tire Co."
                      value={quickShopName}
                      onChange={(e) => setQuickShopName(e.target.value)}
                      className="mt-1 w-full px-3 py-2 text-sm border border-slate-200 rounded-lg"
                    />
                  </label>
                  <label className="block text-xs font-medium text-slate-600">
                    Shop Phone
                    <input
                      type="tel"
                      placeholder="(515) 555-0190"
                      value={quickShopPhone}
                      onChange={(e) => setQuickShopPhone(e.target.value)}
                      className="mt-1 w-full px-3 py-2 text-sm border border-slate-200 rounded-lg"
                    />
                  </label>
                  <label className="block text-xs font-medium text-slate-600">
                    Iowa Tax (%)
                    <input
                      type="number"
                      step="0.01"
                      value={quickTaxRate}
                      onChange={(e) => setQuickTaxRate(e.target.value)}
                      className="mt-1 w-full px-3 py-2 text-sm border border-slate-200 rounded-lg font-mono"
                    />
                  </label>
                  <div className="sm:col-span-4 flex flex-wrap items-center justify-between gap-3 pt-1">
                    <label className="inline-flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={seedMenuChecked}
                        onChange={(e) => setSeedMenuChecked(e.target.checked)}
                        className="rounded border-slate-300"
                      />
                      Also load starter Tire Repair, Tire Sale, Oil Change &amp; Tune-Up price list
                    </label>
                    <button
                      type="submit"
                      disabled={onboardingSaving}
                      className="rounded-lg bg-[#C81E2B] px-4 py-2 text-xs font-semibold text-white hover:bg-[#A61722] min-h-[40px]"
                    >
                      {onboardingSaving ? 'Setting up…' : 'Save & Launch Shop'}
                    </button>
                  </div>
              </form>
            </section>
          )}

          {effectiveTab === 'board' && (
            <DashboardBoard
              workOrders={workOrders}
              effectiveRole={effectiveRole}
              onSelectOrder={(wo) => setModalOrderId(wo.id)}
              onCreateOrder={() => {
                setPrefillCustomer(null);
                setPrefillVehicle(null);
                setShowCreateModal(true);
              }}
              onQuickStatus={handleQuickStatus}
            />
          )}

          {effectiveTab === 'orders' && (
            <DashboardBoard
              workOrders={workOrders}
              effectiveRole={effectiveRole}
              onSelectOrder={(wo) => setModalOrderId(wo.id)}
              onCreateOrder={() => {
                setPrefillCustomer(null);
                setPrefillVehicle(null);
                setShowCreateModal(true);
              }}
              onQuickStatus={handleQuickStatus}
              compactMode
            />
          )}

          {effectiveTab === 'customers' && (
            <CustomersVehiclesView
              customers={customers}
              vehicles={vehicles}
              actor={actor}
              onCreateOrderForVehicle={(customer, vehicle) => {
                setPrefillCustomer(customer);
                setPrefillVehicle(vehicle);
                setShowCreateModal(true);
              }}
            />
          )}

          {effectiveTab === 'prices' && (
            <PriceListView
              services={services}
              priceAuditLog={priceAuditLog}
              effectiveRole={effectiveRole}
              actor={actor}
            />
          )}

          {effectiveTab === 'company' && !isMechanicView && (
            <CompanyStaffExportsView
              company={company}
              staff={staff}
              customers={customers}
              vehicles={vehicles}
              workOrders={workOrders}
              services={services}
              actor={actor}
              effectiveRole={effectiveRole}
              chimeEnabled={chimeEnabled}
              onToggleChime={setChimeEnabled}
            />
          )}
        </main>
      </div>

      {/* Mobile Fixed Bottom Navigation (4 concise destinations, >= 44px hitboxes) */}
      <nav
        aria-label="Mobile Navigation"
        className="md:hidden fixed bottom-0 left-0 right-0 z-30 bg-white/95 backdrop-blur-md border-t border-slate-200 grid grid-cols-4 h-16 pb-safe"
      >
        {(isMechanicView
          ? [navItems[0], navItems[1], navItems[2], navItems[3]]
          : [navItems[0], navItems[2], navItems[3], navItems[4]]
        ).map((item) => {
          const active =
            effectiveTab === item.id ||
            (!isMechanicView && item.id === 'board' && effectiveTab === 'orders');
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setActiveTab(item.id)}
              className={`flex flex-col items-center justify-center min-h-[44px] ${
                active ? 'text-[#C81E2B]' : 'text-slate-500'
              }`}
            >
              {item.icon}
              <span className="text-[10px] font-medium mt-1">{item.shortLabel}</span>
            </button>
          );
        })}
      </nav>

      {/* Work Order Create / Edit / Receipt Modal */}
      {(showCreateModal || modalOrder) && (
        <WorkOrderModal
          existingOrder={modalOrder}
          initialCustomer={prefillCustomer}
          initialVehicle={prefillVehicle}
          customers={customers}
          vehicles={vehicles}
          services={services}
          company={company}
          actor={actor}
          effectiveRole={effectiveRole}
          onClose={() => {
            setShowCreateModal(false);
            setModalOrderId(null);
            setPrefillCustomer(null);
            setPrefillVehicle(null);
          }}
        />
      )}

      <OfflineIndicator pendingCount={pendingWritesCount} />
    </div>
  );
}
