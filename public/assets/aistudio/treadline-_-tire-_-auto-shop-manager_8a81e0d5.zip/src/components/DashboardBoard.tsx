import React, { useMemo, useState } from 'react';
import {
  CheckCircle2,
  Clock,
  FileText,
  PackageOpen,
  Plus,
  Search,
  Wrench,
  XCircle,
} from 'lucide-react';
import { COMPANY_LOGO_SRC } from './BrandLogo';
import { formatCurrency, isSameLocalDay } from '../lib/calculations';
import {
  WORK_ORDER_STATUS_LABELS,
  type StaffRole,
  type WorkOrder,
  type WorkOrderStatus,
} from '../types';

interface DashboardBoardProps {
  workOrders: WorkOrder[];
  effectiveRole: StaffRole;
  onSelectOrder: (wo: WorkOrder) => void;
  onCreateOrder: () => void;
  onQuickStatus: (wo: WorkOrder, nextStatus: WorkOrderStatus) => Promise<void>;
  compactMode?: boolean;
}

type FilterTab = 'active' | 'all' | WorkOrderStatus;

const STATUS_FILTERS: { id: FilterTab; label: string }[] = [
  { id: 'active', label: 'Active Board' },
  { id: 'intake', label: 'Intake' },
  { id: 'in_progress', label: 'In Progress' },
  { id: 'waiting_on_parts', label: 'Waiting on Parts' },
  { id: 'ready', label: 'Ready' },
  { id: 'paid', label: 'Paid' },
  { id: 'voided', label: 'Voided' },
  { id: 'all', label: 'All' },
];

export function StatusText({ status }: { status: WorkOrderStatus }) {
  const styles: Record<WorkOrderStatus, { color: string; icon: React.ReactNode }> = {
    intake: { color: 'text-slate-700', icon: <Clock className="h-3.5 w-3.5 text-slate-500" /> },
    in_progress: {
      color: 'text-[#C81E2B]',
      icon: <Wrench className="h-3.5 w-3.5 text-[#C81E2B]" />,
    },
    waiting_on_parts: {
      color: 'text-amber-700',
      icon: <PackageOpen className="h-3.5 w-3.5 text-amber-600" />,
    },
    ready: {
      color: 'text-emerald-700',
      icon: <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" />,
    },
    paid: {
      color: 'text-slate-900',
      icon: <FileText className="h-3.5 w-3.5 text-slate-700" />,
    },
    voided: {
      color: 'text-red-700',
      icon: <XCircle className="h-3.5 w-3.5 text-red-600" />,
    },
  };
  const cfg = styles[status];
  return (
    <span className={`inline-flex items-center gap-1.5 text-xs font-medium whitespace-nowrap ${cfg.color}`}>
      {cfg.icon}
      {WORK_ORDER_STATUS_LABELS[status]}
    </span>
  );
}

export const DashboardBoard: React.FC<DashboardBoardProps> = ({
  workOrders,
  effectiveRole,
  onSelectOrder,
  onCreateOrder,
  onQuickStatus,
  compactMode = false,
}) => {
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<FilterTab>('active');
  const [busyId, setBusyId] = useState<string | null>(null);
  const [quickError, setQuickError] = useState<string | null>(null);
  const [watermarkFailed, setWatermarkFailed] = useState(false);

  const isMechanic = effectiveRole === 'mechanic';

  const metrics = useMemo(() => {
    const todaysJobs = workOrders.filter(
      (wo) => wo.status !== 'voided' && isSameLocalDay(wo.createdAt)
    ).length;
    const inProgress = workOrders.filter(
      (wo) => wo.status === 'in_progress' || wo.status === 'waiting_on_parts'
    ).length;
    const inBayCount = workOrders.filter((wo) => wo.status === 'in_progress').length;
    const partsHoldCount = workOrders.filter((wo) => wo.status === 'waiting_on_parts').length;
    const readyNotPaidList = workOrders.filter((wo) => wo.status === 'ready');
    const unpaidActive = workOrders.filter(
      (wo) =>
        wo.status === 'intake' ||
        wo.status === 'in_progress' ||
        wo.status === 'waiting_on_parts' ||
        wo.status === 'ready'
    );
    const unpaidTotal = unpaidActive.reduce((sum, wo) => sum + (wo.total || 0), 0);

    return {
      todaysJobs,
      inProgress,
      inBayCount,
      partsHoldCount,
      readyNotPaid: readyNotPaidList.length,
      unpaidTotal,
    };
  }, [workOrders]);

  const filteredOrders = useMemo(() => {
    const q = search.trim().toLowerCase();
    return workOrders.filter((wo) => {
      if (filter === 'active') {
        if (wo.status === 'paid' || wo.status === 'voided') return false;
      } else if (filter !== 'all' && wo.status !== filter) {
        return false;
      }

      if (!q) return true;
      const hay = [
        wo.orderNumber,
        wo.customerName,
        wo.customerPhone,
        wo.licensePlate,
        wo.vin,
        `${wo.vehicleYear} ${wo.vehicleMake} ${wo.vehicleModel}`,
      ]
        .join(' ')
        .toLowerCase();
      return hay.includes(q);
    });
  }, [workOrders, filter, search]);

  const handleQuickAction = async (
    e: React.MouseEvent,
    wo: WorkOrder,
    nextStatus: WorkOrderStatus
  ) => {
    e.stopPropagation();
    setBusyId(wo.id);
    setQuickError(null);
    try {
      await onQuickStatus(wo, nextStatus);
    } catch (err) {
      setQuickError(err instanceof Error ? err.message : 'Unable to update work order status.');
    } finally {
      setBusyId(null);
    }
  };

  const getCardAccentClass = (status: WorkOrderStatus) => {
    switch (status) {
      case 'in_progress':
        return 'border-l-4 border-l-[#C81E2B]';
      case 'waiting_on_parts':
        return 'border-l-4 border-l-amber-500';
      case 'ready':
        return 'border-l-4 border-l-emerald-600';
      case 'intake':
        return 'border-l-4 border-l-slate-900';
      case 'paid':
        return 'border-l-4 border-l-slate-300';
      case 'voided':
        return 'border-l-4 border-l-red-300 opacity-75';
    }
  };

  return (
    <div className="relative space-y-6">
      {!watermarkFailed && (
        <div
          aria-hidden="true"
          className="pointer-events-none select-none fixed inset-0 md:left-60 flex items-center justify-center overflow-hidden z-0 print:hidden"
        >
          <img
            src={COMPANY_LOGO_SRC}
            alt=""
            onError={() => setWatermarkFailed(true)}
            className="w-[360px] sm:w-[500px] lg:w-[640px] max-w-[85vw] aspect-[2/1] object-cover object-[50%_52%] opacity-[0.11] mix-blend-multiply"
          />
        </div>
      )}

      <div className="relative z-10 space-y-6">
        {quickError && (
          <div className="rounded-lg border border-red-200 bg-red-50/95 px-4 py-2.5 text-xs text-red-700">
            {quickError}
          </div>
        )}
        {!compactMode && (
          isMechanic ? (
            <section aria-label="Mechanic Bay Summary" className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-white/80 backdrop-blur-[2px] border border-slate-200/80 rounded-xl p-4 shadow-xs">
                <p className="text-xs font-medium text-slate-500">Today’s Jobs</p>
                <p className="mt-1.5 text-2xl font-bold tracking-tight text-slate-900 font-mono tabular-nums">
                  {metrics.todaysJobs}
                </p>
              </div>
              <div className="bg-white/80 backdrop-blur-[2px] border border-slate-200/80 rounded-xl p-4 shadow-xs">
                <p className="text-xs font-medium text-slate-500">In Progress</p>
                <p className="mt-1.5 text-2xl font-bold tracking-tight text-[#C81E2B] font-mono tabular-nums">
                  {metrics.inBayCount}
                </p>
              </div>
              <div className="bg-white/80 backdrop-blur-[2px] border border-slate-200/80 rounded-xl p-4 shadow-xs">
                <p className="text-xs font-medium text-slate-500">Waiting on Parts</p>
                <p className="mt-1.5 text-2xl font-bold tracking-tight text-amber-600 font-mono tabular-nums">
                  {metrics.partsHoldCount}
                </p>
              </div>
              <div className="bg-white/80 backdrop-blur-[2px] border border-slate-200/80 rounded-xl p-4 shadow-xs">
                <p className="text-xs font-medium text-slate-500">Ready for Counter</p>
                <p className="mt-1.5 text-2xl font-bold tracking-tight text-emerald-700 font-mono tabular-nums">
                  {metrics.readyNotPaid}
                </p>
              </div>
            </section>
          ) : (
            <section aria-label="Today's Shop Summary" className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-white/80 backdrop-blur-[2px] border border-slate-200/80 rounded-xl p-4 shadow-xs">
                <p className="text-xs font-medium text-slate-500">Today’s Jobs</p>
                <p className="mt-1.5 text-2xl font-bold tracking-tight text-slate-900 font-mono tabular-nums">
                  {metrics.todaysJobs}
                </p>
              </div>
              <div className="bg-white/80 backdrop-blur-[2px] border border-slate-200/80 rounded-xl p-4 shadow-xs">
                <p className="text-xs font-medium text-slate-500">In Bay / Parts Hold</p>
                <p className="mt-1.5 text-2xl font-bold tracking-tight text-[#C81E2B] font-mono tabular-nums">
                  {metrics.inProgress}
                </p>
              </div>
              <div className="bg-white/80 backdrop-blur-[2px] border border-slate-200/80 rounded-xl p-4 shadow-xs">
                <p className="text-xs font-medium text-slate-500">Ready · Not Paid</p>
                <p className="mt-1.5 text-2xl font-bold tracking-tight text-emerald-700 font-mono tabular-nums">
                  {metrics.readyNotPaid}
                </p>
              </div>
              <div className="bg-white/80 backdrop-blur-[2px] border border-slate-200/80 rounded-xl p-4 shadow-xs">
                <p className="text-xs font-medium text-slate-500">Unpaid Total</p>
                <p className="mt-1.5 text-2xl font-bold tracking-tight text-slate-900 font-mono tabular-nums">
                  {formatCurrency(metrics.unpaidTotal)}
                </p>
              </div>
            </section>
          )
        )}

        {/* Translucent Work Order Board Area */}
        <section className="bg-white/35 backdrop-blur-[1.5px] border border-slate-200/80 rounded-2xl overflow-hidden shadow-xs">
          <div className="p-4 bg-white/70 border-b border-slate-200/80 flex flex-col lg:flex-row lg:items-center gap-3 justify-between">
            <div className="flex flex-col sm:flex-row sm:items-center gap-2.5 flex-1">
              <div className="relative flex-1 max-w-md">
                <Search className="h-4 w-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="search"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search customer, phone, plate, VIN, or WO#..."
                  className="w-full pl-9 pr-3 py-2 text-sm bg-white/85 border border-slate-200 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-none focus:bg-white focus:border-slate-400 min-h-[40px]"
                />
              </div>
            </div>

            <div className="flex items-center gap-1 p-1 bg-slate-100/90 rounded-lg overflow-x-auto">
              {STATUS_FILTERS.filter((tab) =>
                isMechanic ? tab.id !== 'voided' : true
              ).map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setFilter(tab.id)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 min-h-[34px] ${
                    filter === tab.id
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* Card List / Empty Canvas */}
          <div className="p-4 min-h-[300px]">
            {filteredOrders.length === 0 ? (
              <div className="min-h-[260px] flex flex-col items-center justify-center py-10 px-6 text-center">
                <p className="text-sm font-semibold text-slate-900">
                  {workOrders.length === 0
                    ? 'No work orders yet'
                    : 'No matching work orders for this filter'}
                </p>
                <p className="mt-1 text-xs text-slate-600 max-w-md">
                  {workOrders.length === 0
                    ? 'Create your first work order to log a tire repair, tire sale, oil change, or tune-up.'
                    : 'Try clearing the search query or switching to All work orders.'}
                </p>
                <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
                  <button
                    type="button"
                    onClick={onCreateOrder}
                    className="inline-flex items-center gap-2 rounded-lg bg-slate-900 px-4 py-2 text-xs font-medium text-white hover:bg-slate-800 transition-colors min-h-[40px] shadow-xs"
                  >
                    <Plus className="h-3.5 w-3.5" />
                    New Work Order
                  </button>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-3.5">
                {filteredOrders.map((wo) => {
                  const previewServices = wo.lineItems
                    .slice(0, 2)
                    .map((li) => (li.qty > 1 ? `${li.qty}× ${li.name}` : li.name))
                    .join(' · ');
                  const extraCount = Math.max(0, wo.lineItems.length - 2);

                  return (
                    <article
                      key={wo.id}
                      onClick={() => onSelectOrder(wo)}
                      role="button"
                      tabIndex={0}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' || e.key === ' ') {
                          e.preventDefault();
                          onSelectOrder(wo);
                        }
                      }}
                      className={`bg-white/90 backdrop-blur-sm border border-slate-200/90 hover:border-slate-300 hover:bg-white rounded-xl p-4 shadow-xs transition-all cursor-pointer flex flex-col justify-between gap-3 ${getCardAccentClass(
                        wo.status
                      )}`}
                    >
                      <div className="space-y-2.5">
                        {/* Top Header: WO# + Status + Total */}
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex flex-wrap items-center gap-2 min-w-0">
                            <span className="font-mono text-xs font-bold text-slate-900">
                              {wo.orderNumber}
                            </span>
                            <span className="text-slate-300" aria-hidden="true">
                              ·
                            </span>
                            <StatusText status={wo.status} />
                            {wo.hasPendingWrites && (
                              <span className="text-[11px] font-medium text-amber-600">
                                · Saved offline
                              </span>
                            )}
                          </div>

                          <div className="text-right shrink-0">
                            <p className="text-sm font-bold font-mono tabular-nums text-slate-900">
                              {isMechanic
                                ? `${wo.lineItems.length} item${wo.lineItems.length === 1 ? '' : 's'}`
                                : formatCurrency(wo.total)}
                            </p>
                            {wo.status === 'paid' && (
                              <p className="text-[10px] font-medium text-slate-500 uppercase">
                                Paid · {wo.paymentMethod}
                              </p>
                            )}
                          </div>
                        </div>

                        {/* Vehicle & Customer Details */}
                        <div>
                          <h3 className="text-sm font-bold text-slate-900 leading-snug">
                            {wo.vehicleYear} {wo.vehicleMake} {wo.vehicleModel}
                          </h3>
                          <p className="mt-0.5 text-xs text-slate-600">
                            <span className="font-medium text-slate-800">{wo.customerName}</span>
                            {wo.customerPhone && (
                              <span className="font-mono tabular-nums text-slate-500">
                                {' '}
                                · {wo.customerPhone}
                              </span>
                            )}
                          </p>
                          <p className="mt-0.5 text-[11px] font-mono tabular-nums text-slate-500">
                            {wo.licensePlate || 'No plate'} · {wo.mileage.toLocaleString()} mi
                          </p>
                        </div>

                        {previewServices && (
                          <p className="text-xs text-slate-600 truncate">
                            {previewServices}
                            {extraCount > 0 ? ` +${extraCount} more` : ''}
                          </p>
                        )}
                      </div>

                      {/* Footer: Creator & Quick Steps */}
                      <div className="pt-2.5 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2">
                        <span className="text-xs text-slate-500 truncate">
                          Opened by <span className="font-medium text-slate-700">{wo.createdByName || 'Shop'}</span>
                        </span>

                        <div className="flex items-center gap-1.5 shrink-0">
                          {wo.status === 'intake' && (
                            <button
                              type="button"
                              disabled={busyId === wo.id}
                              onClick={(e) => handleQuickAction(e, wo, 'in_progress')}
                              className="px-3 py-1.5 min-h-[44px] md:min-h-[38px] text-xs font-medium rounded-lg border border-slate-200 bg-white text-slate-800 hover:bg-slate-100 transition-colors"
                            >
                              Start Job
                            </button>
                          )}
                          {wo.status === 'in_progress' && (
                            <button
                              type="button"
                              disabled={busyId === wo.id}
                              onClick={(e) => handleQuickAction(e, wo, 'waiting_on_parts')}
                              className="px-3 py-1.5 min-h-[44px] md:min-h-[38px] text-xs font-medium rounded-lg border border-amber-200 bg-amber-50 text-amber-800 hover:bg-amber-100 transition-colors"
                            >
                              Parts Hold
                            </button>
                          )}
                          {(wo.status === 'in_progress' || wo.status === 'waiting_on_parts') && (
                            <button
                              type="button"
                              disabled={busyId === wo.id}
                              onClick={(e) => handleQuickAction(e, wo, 'ready')}
                              className="px-3 py-1.5 min-h-[44px] md:min-h-[38px] text-xs font-medium rounded-lg bg-emerald-600 text-white hover:bg-emerald-700 transition-colors"
                            >
                              Mark Ready
                            </button>
                          )}
                          {wo.status === 'ready' && (
                            <span className="text-xs font-medium text-emerald-700">
                              {isMechanic ? 'Awaiting Counter' : 'Open to Collect'}
                            </span>
                          )}
                          {(wo.status === 'paid' || wo.status === 'voided') && (
                            <span className="text-xs text-slate-400">View Receipt</span>
                          )}
                        </div>
                      </div>
                    </article>
                  );
                })}
              </div>
            )}
          </div>
        </section>
      </div>
    </div>
  );
};
