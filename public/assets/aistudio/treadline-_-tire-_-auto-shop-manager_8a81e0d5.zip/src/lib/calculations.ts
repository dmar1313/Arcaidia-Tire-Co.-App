import type { ServiceCatalogItem, WorkOrderLineItem } from '../types';

export function roundCents(value: number): number {
  return Math.round((value + Number.EPSILON) * 100) / 100;
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(Number.isFinite(amount) ? amount : 0);
}

export function calculateWorkOrderTotals(
  lineItems: WorkOrderLineItem[],
  discountInput: number,
  taxRatePercent: number
): {
  subtotal: number;
  discount: number;
  taxableSubtotal: number;
  taxAmount: number;
  total: number;
} {
  const subtotal = roundCents(
    lineItems.reduce((sum, item) => sum + Math.max(0, item.qty) * Math.max(0, item.unitPrice), 0)
  );
  const discount = roundCents(Math.min(subtotal, Math.max(0, discountInput || 0)));

  const rawTaxable = roundCents(
    lineItems.reduce(
      (sum, item) =>
        item.taxable ? sum + Math.max(0, item.qty) * Math.max(0, item.unitPrice) : sum,
      0
    )
  );

  // Proportionally reduce taxable base when a work-order discount is applied
  const discountRatio = subtotal > 0 ? discount / subtotal : 0;
  const taxableSubtotal = roundCents(Math.max(0, rawTaxable * (1 - discountRatio)));
  const taxRate = Math.max(0, taxRatePercent || 0) / 100;
  const taxAmount = roundCents(taxableSubtotal * taxRate);
  const total = roundCents(Math.max(0, subtotal - discount + taxAmount));

  return {
    subtotal,
    discount,
    taxableSubtotal,
    taxAmount,
    total,
  };
}

export function generateWorkOrderNumber(prefix: string): string {
  const now = new Date();
  const yy = String(now.getFullYear()).slice(-2);
  const mm = String(now.getMonth() + 1).padStart(2, '0');
  const dd = String(now.getDate()).padStart(2, '0');
  const suffix = String(Math.floor(1000 + Math.random() * 9000));
  const cleanPrefix = (prefix || 'WO-').trim().slice(0, 10);
  return `${cleanPrefix}${yy}${mm}${dd}-${suffix}`;
}

export function formatTimestamp(value: unknown): string {
  if (!value) return 'Pending sync';
  if (typeof value === 'string') {
    const d = new Date(value);
    return Number.isNaN(d.getTime()) ? value : d.toLocaleString();
  }
  if (typeof value === 'object' && value !== null && 'toDate' in value) {
    const fn = (value as { toDate?: () => Date }).toDate;
    if (typeof fn === 'function') {
      return fn().toLocaleString();
    }
  }
  return 'Just now';
}

export function isSameLocalDay(value: unknown, referenceDate = new Date()): boolean {
  let d: Date | null = null;
  if (!value) return true; // Newly created offline local write counts as today
  if (typeof value === 'string') {
    const parsed = new Date(value);
    if (!Number.isNaN(parsed.getTime())) d = parsed;
  } else if (typeof value === 'object' && value !== null && 'toDate' in value) {
    const fn = (value as { toDate?: () => Date }).toDate;
    if (typeof fn === 'function') d = fn();
  }
  if (!d) return true;
  return (
    d.getFullYear() === referenceDate.getFullYear() &&
    d.getMonth() === referenceDate.getMonth() &&
    d.getDate() === referenceDate.getDate()
  );
}

export const DEFAULT_SHOP_SERVICES: Array<
  Omit<ServiceCatalogItem, 'id' | 'updatedByUid' | 'createdAt' | 'updatedAt'>
> = [
  {
    name: 'Flat Tire Repair (Patch & Plug)',
    category: 'tire_repair',
    description: 'Internal patch-plug repair, bead clean, leak test, and torque check.',
    unitPrice: 28.0,
    taxable: true,
    active: true,
  },
  {
    name: 'Mount & Balance (Per Tire)',
    category: 'tire_repair',
    description: 'Dismount old tire, mount tire, computer spin balance, and torque lugs.',
    unitPrice: 25.0,
    taxable: true,
    active: true,
  },
  {
    name: '4-Tire Rotation & Pressure Check',
    category: 'tire_repair',
    description: 'Cross/front-to-back rotation, tread depth inspection, and PSI set.',
    unitPrice: 24.0,
    taxable: true,
    active: true,
  },
  {
    name: 'All-Season Passenger Tire (225/65R17)',
    category: 'tire_sale',
    description: '65,000-mile rated all-season tire (unit price per tire).',
    unitPrice: 138.0,
    taxable: true,
    active: true,
  },
  {
    name: 'Light Truck A/T Tire (265/70R17)',
    category: 'tire_sale',
    description: 'All-terrain light truck tire (unit price per tire).',
    unitPrice: 196.0,
    taxable: true,
    active: true,
  },
  {
    name: 'TPMS Sensor Replacement & Relearn',
    category: 'part',
    description: 'New programmable TPMS sensor + OBD relearn.',
    unitPrice: 65.0,
    taxable: true,
    active: true,
  },
  {
    name: 'Rubber Valve Stem',
    category: 'part',
    description: 'Standard TR413 rubber snap-in valve stem.',
    unitPrice: 6.0,
    taxable: true,
    active: true,
  },
  {
    name: 'Conventional Oil & Filter Change (Up to 5 qt)',
    category: 'oil_change',
    description: 'Oil, filter, drain plug gasket, fluid top-off, and tire pressure check.',
    unitPrice: 49.95,
    taxable: true,
    active: true,
  },
  {
    name: 'Full Synthetic Oil & Filter Change (Up to 5 qt)',
    category: 'oil_change',
    description: '0W-20 / 5W-30 full synthetic oil, OEM-grade filter, and multi-point check.',
    unitPrice: 74.95,
    taxable: true,
    active: true,
  },
  {
    name: 'Basic 4-Cylinder Tune-Up',
    category: 'tune_up',
    description: 'Replace 4 iridium spark plugs, inspect ignition coils, air filter & idle check.',
    unitPrice: 165.0,
    taxable: true,
    active: true,
  },
  {
    name: 'V6 / V8 Tune-Up Service',
    category: 'tune_up',
    description: 'Replace spark plugs, inspect boots/coils, throttle body & filter check.',
    unitPrice: 245.0,
    taxable: true,
    active: true,
  },
];
