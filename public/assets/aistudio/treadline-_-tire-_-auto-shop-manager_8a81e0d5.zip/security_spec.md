# Security Specification & Dirty Dozen Audit

## 1. Data Invariants
1. Only Google-authenticated, email-verified users (`email_verified == true`) who are either the bootstrapped owner (`davidntak@gmail.com`) or listed as `active == true` in `/staff/{emailKey}` can read or write shop data.
2. Only `management` role (or bootstrapped owner) can create/update `/company`, `/staff`, `/services`, and `/price_audit_log`. Mechanics have read-only access to those collections.
3. No deletions are permitted on `/customers`, `/vehicles`, `/work_orders`, `/work_orders/{id}/audit_log`, `/price_audit_log`, or `/company`.
4. Mechanics cannot create or update a work order with `status` set to `paid` or `voided`, cannot modify `discount`, `taxRate`, `paymentMethod`, `amountPaid`, or `paid*` fields, and cannot modify any `paid` or `voided` work order.
5. Paid work orders are locked against edits to line items, prices, customer, vehicle, or totals. Only `management` can transition a `paid` work order to `voided`, and only with a non-empty `voidReason` (>= 3 chars). Voided work orders are permanently immutable.
6. Audit log entries (`/work_orders/{id}/audit_log/{logId}` and `/price_audit_log/{logId}`) are append-only (`allow update, delete: if false`).
7. Every vehicle must reference an existing customer (`exists` or `existsAfter`), and every work order must reference an existing customer and vehicle (`exists` or `existsAfter`).
8. All timestamps (`createdAt`, `updatedAt`) are strictly validated against `request.time`. All document IDs match `^[a-zA-Z0-9_\-]+$` with length <= 128.

## 2. The Dirty Dozen Adversarial Payloads
1. **Unauthenticated Read/Write**: Attempt to read `/customers` or create `/work_orders` without `request.auth`. -> Expected: `PERMISSION_DENIED`.
2. **Unverified Email Spoof**: Auth token with `email == 'davidntak@gmail.com'` and `email_verified == false` attempting to update `/services`. -> Expected: `PERMISSION_DENIED`.
3. **Outsider Google Account**: Verified Google user not present in `/staff` attempting to list `/work_orders` or read `/customers`. -> Expected: `PERMISSION_DENIED`.
4. **Mechanic Price Catalog Escalation**: Active mechanic attempting to update `unitPrice` on `/services/svc_1`. -> Expected: `PERMISSION_DENIED`.
5. **Mechanic Role Self-Promotion**: Active mechanic attempting to update their own `/staff/{id}` document to `role: 'management'`. -> Expected: `PERMISSION_DENIED`.
6. **Mechanic Discount Injection**: Active mechanic attempting to update `/work_orders/wo_1` with `discount: 50` or changing `taxRate`. -> Expected: `PERMISSION_DENIED`.
7. **Mechanic Mark Paid Bypass**: Active mechanic attempting to update `/work_orders/wo_1` status to `paid` with `paymentMethod: 'cash'`. -> Expected: `PERMISSION_DENIED`.
8. **Paid Order Tampering**: Management attempting to modify `total` or `lineItems` on a work order whose existing status is `paid`. -> Expected: `PERMISSION_DENIED`.
9. **Void Without Reason**: Management attempting to transition a `paid` work order to `voided` with `voidReason: ''`. -> Expected: `PERMISSION_DENIED`.
10. **Work Order Deletion**: Management attempting to `delete` `/work_orders/wo_1`. -> Expected: `PERMISSION_DENIED`.
11. **Shadow Field Injection**: Authenticated staff attempting to create `/customers/cust_1` with extra field `isAdmin: true`. -> Expected: `PERMISSION_DENIED`.
12. **Client Timestamp Forgery & ID Poisoning**: Attempting to create `/work_orders/wo_1` with backdated `createdAt` (`!= request.time`) or a 500-char invalid document ID. -> Expected: `PERMISSION_DENIED`.
